<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Storelocator
 */


namespace Amasty\Storelocator\Model\Import\Proxy\Location;

/**
 * Class ResourceModel
 */
class ResourceModel extends \Amasty\Storelocator\Model\ResourceModel\Location
{
}
