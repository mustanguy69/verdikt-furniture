var config = {
    map: {
        '*': {
            amasty_acart_grabemail: 'Amasty_Acart/js/grabemail'
        }
    },
    deps: [
    ]
};